<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/prefectures.php';
require_once __DIR__ . '/../config/csrf.php';

require_login();
csrf_verify();

$pdo = db();
$prefMap = prefecture_map();

/* ===== サムネ関数（create.phpと同等）===== */
function safe_image_extension(string $tmpPath): ?string
{
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = $finfo ? finfo_file($finfo, $tmpPath) : '';
    if ($finfo) finfo_close($finfo);

    return match ($mime) {
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        default      => null,
    };
}

function create_thumbnail(string $srcPath, string $dstPath, int $maxW = 360, int $maxH = 270): void
{
    $info = getimagesize($srcPath);
    if ($info === false) throw new RuntimeException('画像情報が取得できません');

    [$w, $h] = $info;
    $mime = $info['mime'] ?? '';

    $srcImg = match ($mime) {
        'image/jpeg' => imagecreatefromjpeg($srcPath),
        'image/png'  => imagecreatefrompng($srcPath),
        'image/webp' => imagecreatefromwebp($srcPath),
        default      => null,
    };
    if (!$srcImg) throw new RuntimeException('対応していない画像形式です');

    $scale = min($maxW / $w, $maxH / $h, 1.0);
    $newW = (int)max(1, floor($w * $scale));
    $newH = (int)max(1, floor($h * $scale));

    $dstImg = imagecreatetruecolor($newW, $newH);
    $white = imagecolorallocate($dstImg, 255, 255, 255);
    imagefilledrectangle($dstImg, 0, 0, $newW, $newH, $white);

    imagecopyresampled($dstImg, $srcImg, 0, 0, 0, 0, $newW, $newH, $w, $h);

    if (!imagejpeg($dstImg, $dstPath, 82)) {
        imagedestroy($srcImg);
        imagedestroy($dstImg);
        throw new RuntimeException('サムネ生成に失敗しました');
    }

    imagedestroy($srcImg);
    imagedestroy($dstImg);
}

/* ===== 入力 ===== */
$routeId = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
if (!$routeId) {
    http_response_code(400);
    exit('不正なIDです');
}

/* 所有者確認 */
$stmt = $pdo->prepare('SELECT * FROM routes WHERE id = :id');
$stmt->execute([':id' => $routeId]);
$route = $stmt->fetch();
if (!$route) {
    http_response_code(404);
    exit('投稿が見つかりません');
}
if ((int)$route['user_id'] !== (int)$_SESSION['user_id']) {
    http_response_code(403);
    exit('権限がありません');
}

/* ===== フィールド ===== */
$title = trim($_POST['title'] ?? '');
$summary = trim($_POST['summary'] ?? '');
$description = trim($_POST['description'] ?? '');

$address = trim($_POST['address'] ?? '');
$site_url = trim($_POST['site_url'] ?? '');

$mainPref = filter_input(INPUT_POST, 'prefecture_code', FILTER_VALIDATE_INT);
$sub_prefectures = $_POST['sub_prefectures'] ?? [];

/* ルート（住所） */
$startLabel = trim($_POST['start_label'] ?? '');
$startAddress = trim($_POST['start_address'] ?? '');
$middleLabels = $_POST['middle_label'] ?? [];
$middleAddresses = $_POST['middle_address'] ?? [];
$goalLabel = trim($_POST['goal_label'] ?? '');
$goalAddress = trim($_POST['goal_address'] ?? '');

/* ===== バリデーション（最低限） ===== */
$errors = [];
if ($title === '' || mb_strlen($title) > 100) $errors[] = 'タイトルは必須（100文字以内）です';
if ($summary !== '' && mb_strlen($summary) > 255) $errors[] = '概要は255文字以内にしてください';
if (!$mainPref || !isset($prefMap[$mainPref])) $errors[] = 'メイン都道府県が不正です';

if ($address !== '' && mb_strlen($address) > 255) $errors[] = '住所は255文字以内にしてください';
if ($site_url !== '' && !filter_var($site_url, FILTER_VALIDATE_URL)) $errors[] = '目的地のサイトは正しいURL形式で入力してください';

if ($errors) {
    http_response_code(400);
    exit(implode("\n", $errors));
}

try {
    $pdo->beginTransaction();

    /* ① routes 更新
       ✅ 正：site_url に保存
       ✅ map_url は後方互換のため、ここでは触れない（読むだけ）
    */
    $up = $pdo->prepare('
      UPDATE routes
      SET title=:t, summary=:s, description=:d, address=:a, site_url=:su, prefecture_code=:p
      WHERE id=:id
    ');
    $up->execute([
        ':t' => $title,
        ':s' => $summary !== '' ? $summary : null,
        ':d' => $description !== '' ? $description : null,
        ':a' => $address !== '' ? $address : null,
        ':su' => $site_url !== '' ? $site_url : null,
        ':p' => $mainPref,
        ':id' => $routeId
    ]);

    /* ② route_prefectures 更新（入れ替え方式） */
    $pdo->prepare('DELETE FROM route_prefectures WHERE route_id=:rid')->execute([':rid' => $routeId]);

    $rpStmt = $pdo->prepare('
      INSERT INTO route_prefectures (route_id, prefecture_code, is_main)
      VALUES (:rid, :code, :is_main)
    ');
    $rpStmt->execute([':rid' => $routeId, ':code' => $mainPref, ':is_main' => 1]);

    foreach (array_unique($sub_prefectures) as $code) {
        $code = (int)$code;
        if ($code === $mainPref || !isset($prefMap[$code])) continue;
        $rpStmt->execute([':rid' => $routeId, ':code' => $code, ':is_main' => 0]);
    }

    /* ③ route_points 更新（入れ替え方式）
       ※ urlカラムを「住所」として利用
    */
    $pdo->prepare('DELETE FROM route_points WHERE route_id=:rid')->execute([':rid' => $routeId]);

    $ptStmt = $pdo->prepare('
      INSERT INTO route_points (route_id, point_type, label, url, sort_order)
      VALUES (:rid, :type, :label, :addr, :ord)
    ');

    if ($startLabel !== '' || $startAddress !== '') {
        $ptStmt->execute([
            ':rid' => $routeId,
            ':type' => 'start',
            ':label' => ($startLabel !== '' ? $startLabel : 'スタート'),
            ':addr' => ($startAddress !== '' ? $startAddress : null),
            ':ord' => 0
        ]);
    }

    foreach ($middleLabels as $i => $label) {
        $label = trim((string)$label);
        $addr = trim((string)($middleAddresses[$i] ?? ''));
        if ($label === '' && $addr === '') continue;

        $ptStmt->execute([
            ':rid' => $routeId,
            ':type' => 'middle',
            ':label' => ($label !== '' ? $label : '中間地点'),
            ':addr' => ($addr !== '' ? $addr : null),
            ':ord' => $i + 1
        ]);
    }

    if ($goalLabel !== '' || $goalAddress !== '') {
        $ptStmt->execute([
            ':rid' => $routeId,
            ':type' => 'goal',
            ':label' => ($goalLabel !== '' ? $goalLabel : 'ゴール'),
            ':addr' => ($goalAddress !== '' ? $goalAddress : null),
            ':ord' => 999
        ]);
    }

    /* アップロード先（存在しないケース対策で base も作る） */
    $uploadBase = __DIR__ . '/../uploads/routes/' . $routeId;
    $thumbDir = $uploadBase . '/thumbs';
    if (!is_dir($uploadBase)) {
        if (!mkdir($uploadBase, 0777, true) && !is_dir($uploadBase)) {
            throw new RuntimeException('アップロードフォルダを作成できません');
        }
    }
    if (!is_dir($thumbDir)) {
        if (!mkdir($thumbDir, 0777, true) && !is_dir($thumbDir)) {
            throw new RuntimeException('サムネフォルダを作成できません');
        }
    }

    /* ④ 写真削除（thumbも削除） */
    $deleteIds = $_POST['delete_photo_ids'] ?? [];

    if (is_array($deleteIds) && $deleteIds) {
        $deleteIds = array_values(array_filter(array_map('intval', $deleteIds), fn($v) => $v > 0));
        if ($deleteIds) {
            $in = implode(',', array_fill(0, count($deleteIds), '?'));
            $sel = $pdo->prepare("SELECT id, file_name, thumb_name FROM route_photos WHERE route_id=? AND id IN ($in)");
            $sel->execute(array_merge([$routeId], $deleteIds));
            $rows = $sel->fetchAll();

            foreach ($rows as $r) {
                @unlink($uploadBase . '/' . $r['file_name']);
                if (!empty($r['thumb_name'])) {
                    @unlink($thumbDir . '/' . $r['thumb_name']);
                }
            }

            $del = $pdo->prepare("DELETE FROM route_photos WHERE route_id=? AND id IN ($in)");
            $del->execute(array_merge([$routeId], $deleteIds));
        }
    }

    /* ⑤ 写真追加（thumbも生成） */
    if (!empty($_FILES['photos']) && isset($_FILES['photos']['tmp_name']) && is_array($_FILES['photos']['tmp_name'])) {

        // 現在の枚数（削除後を考慮）
        $cntStmt = $pdo->prepare('SELECT COUNT(*) FROM route_photos WHERE route_id=?');
        $cntStmt->execute([$routeId]);
        $currentCount = (int)$cntStmt->fetchColumn();

        // 追加予定数（UPLOAD_ERR_NO_FILE除外）
        $errArr = $_FILES['photos']['error'] ?? [];
        $addCandidates = 0;
        foreach ($errArr as $e) {
            if ((int)$e !== UPLOAD_ERR_NO_FILE) $addCandidates++;
        }

        if ($currentCount + $addCandidates > 10) {
            throw new RuntimeException('写真は合計で最大10枚までです（削除してから追加してください）');
        }

        // sort_order を末尾に積む
        $maxStmt = $pdo->prepare('SELECT COALESCE(MAX(sort_order), -1) FROM route_photos WHERE route_id=?');
        $maxStmt->execute([$routeId]);
        $sort = (int)$maxStmt->fetchColumn() + 1;

        $photoInsert = $pdo->prepare('
          INSERT INTO route_photos (route_id, file_name, thumb_name, sort_order)
          VALUES (:rid, :file, :thumb, :ord)
        ');

        foreach ($_FILES['photos']['tmp_name'] as $i => $tmp) {
            $err = (int)($_FILES['photos']['error'][$i] ?? UPLOAD_ERR_NO_FILE);
            if ($err === UPLOAD_ERR_NO_FILE) continue;
            if ($err !== UPLOAD_ERR_OK) throw new RuntimeException('写真アップロードに失敗したファイルがあります');
            if (!is_uploaded_file($tmp)) throw new RuntimeException('不正なアップロードが検出されました');

            $ext = safe_image_extension($tmp);
            if ($ext === null) throw new RuntimeException('対応していない画像形式があります（jpg/png/webpのみ）');

            $newName = bin2hex(random_bytes(16)) . '.' . $ext;
            $dest = $uploadBase . '/' . $newName;

            if (!move_uploaded_file($tmp, $dest)) {
                throw new RuntimeException('写真の保存に失敗しました');
            }

            $thumbName = 't_' . bin2hex(random_bytes(16)) . '.jpg';
            $thumbPath = $thumbDir . '/' . $thumbName;

            create_thumbnail($dest, $thumbPath, 360, 270);

            $photoInsert->execute([
                ':rid' => $routeId,
                ':file' => $newName,
                ':thumb' => $thumbName,
                ':ord' => $sort++,
            ]);
        }
    }

    $pdo->commit();

    header('Location: /routes/show.php?id=' . $routeId);
    exit;
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(400);
    exit('更新に失敗しました：' . $e->getMessage());
}
